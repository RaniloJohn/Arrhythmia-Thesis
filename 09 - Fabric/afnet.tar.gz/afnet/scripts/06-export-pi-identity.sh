#!/usr/bin/env bash
# mint1. Packs the Pi's client identity (User1@hospital) + TLS CA into pi-identity.tar.gz
#   scp pi-identity.tar.gz pi@<pi>:~/   then on Pi: mkdir -p ~/af-edge/identity && tar xzf pi-identity.tar.gz -C ~/af-edge/identity
set -euo pipefail
source "$(dirname "$0")/env.sh"
cd "$AFNET"
U="$AFNET/organizations/peerOrganizations/hospital.af.local/users/User1@hospital.af.local/msp"
T="$(mktemp -d)"
cp "$U"/signcerts/*.pem "$T/cert.pem"
cp "$U"/keystore/*_sk   "$T/key.pem"
cp "$HOSPITAL_TLS_CA"   "$T/tls-ca.pem"
chmod 600 "$T/key.pem"
tar czf pi-identity.tar.gz -C "$T" cert.pem key.pem tls-ca.pem
rm -rf "$T"
echo "OK: $AFNET/pi-identity.tar.gz"

#!/usr/bin/env bash
# mint1 only. Copies each host ONLY the crypto it runs (no other org's admin keys).
#   bash scripts/02-distribute.sh <ssh-user>
set -euo pipefail
U="${1:?usage: 02-distribute.sh <ssh-user>}"
source "$(dirname "$0")/env.sh"
cd "$AFNET"
O=organizations/ordererOrganizations/orderer.af.local
H=organizations/peerOrganizations/hospital.af.local
C=organizations/peerOrganizations/clinic.af.local

push() {  # push <host> <paths...>
  local host="$1"; shift
  tar czf - "$@" channel-artifacts | ssh "$U@$host" "mkdir -p ~/afnet && tar xzf - -C ~/afnet"
  echo "-> $host: $*"
}
push 192.168.68.111 "$O/orderers/orderer2.orderer.af.local" "$H/peers/peer1.hospital.af.local"
push 192.168.68.112 "$O/orderers/orderer3.orderer.af.local" "$C/peers/peer0.clinic.af.local"
push 192.168.68.113 "$C/peers/peer1.clinic.af.local"
echo "Done. Admin identities stay on mint1."

#!/usr/bin/env bash
# source scripts/env.sh   (from ~/afnet)
# Admin CLI environment. All admin ops run from mint1 against remote peers/orderers.

export AFNET="${AFNET:-$HOME/afnet}"
export PATH="$AFNET/bin:$PATH"
export FABRIC_CFG_PATH="$AFNET/config"          # core.yaml from install-fabric.sh
export CHANNEL=afchannel
export CC_NAME=afevents

ORG="$AFNET/organizations"
export ORDERER_CA="$ORG/ordererOrganizations/orderer.af.local/tlsca/tlsca.orderer.af.local-cert.pem"
export ORDERER_ADMIN_TLS_CERT="$ORG/ordererOrganizations/orderer.af.local/users/Admin@orderer.af.local/tls/client.crt"
export ORDERER_ADMIN_TLS_KEY="$ORG/ordererOrganizations/orderer.af.local/users/Admin@orderer.af.local/tls/client.key"
export ORDERER=orderer1.orderer.af.local:7050

export HOSPITAL_TLS_CA="$ORG/peerOrganizations/hospital.af.local/tlsca/tlsca.hospital.af.local-cert.pem"
export CLINIC_TLS_CA="$ORG/peerOrganizations/clinic.af.local/tlsca/tlsca.clinic.af.local-cert.pem"

# set_peer hospital0 | hospital1 | clinic0 | clinic1
set_peer() {
  local org="${1%[01]}" n="${1: -1}"
  case "$org" in
    hospital) export CORE_PEER_LOCALMSPID=HospitalMSP ;;
    clinic)   export CORE_PEER_LOCALMSPID=ClinicMSP ;;
    *) echo "usage: set_peer hospital0|hospital1|clinic0|clinic1" >&2; return 1 ;;
  esac
  export CORE_PEER_TLS_ENABLED=true
  export CORE_PEER_ADDRESS="peer${n}.${org}.af.local:7051"
  export CORE_PEER_TLS_ROOTCERT_FILE="$ORG/peerOrganizations/${org}.af.local/tlsca/tlsca.${org}.af.local-cert.pem"
  export CORE_PEER_MSPCONFIGPATH="$ORG/peerOrganizations/${org}.af.local/users/Admin@${org}.af.local/msp"
}

# Endorsing peers for invoke/commit (one per org = MAJORITY of 2)
export ENDORSERS=(--peerAddresses peer0.hospital.af.local:7051 --tlsRootCertFiles "$HOSPITAL_TLS_CA"
                  --peerAddresses peer0.clinic.af.local:7051   --tlsRootCertFiles "$CLINIC_TLS_CA")

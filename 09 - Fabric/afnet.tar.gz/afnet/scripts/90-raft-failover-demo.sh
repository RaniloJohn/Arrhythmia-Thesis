#!/usr/bin/env bash
# Panel demo. Run on mint2 (stops orderer2), then run 05-smoke-test.sh on mint1:
# writes still commit with 2/3 orderers. Stop a second orderer -> writes halt.
set -euo pipefail
case "${1:-stop}" in
  stop)  docker stop orderer2.orderer.af.local ;;
  start) docker start orderer2.orderer.af.local ;;
  *) echo "usage: $0 stop|start" ;;
esac

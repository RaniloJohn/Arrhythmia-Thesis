#!/usr/bin/env bash
# mint1. Writes one test event, reads it back from every peer, verifies hash.
set -euo pipefail
source "$(dirname "$0")/env.sh"
cd "$AFNET"

ID="test-$(date +%s)"
TS="$(date -u +%Y-%m-%dT%H:%M:%S.000Z)"
HASH="$(echo -n "$ID|$TS" | sha256sum | cut -d' ' -f1)"

set_peer hospital0
peer chaincode invoke -o "$ORDERER" --tls --cafile "$ORDERER_CA" -C "$CHANNEL" -n "$CC_NAME" \
  "${ENDORSERS[@]}" --waitForEvent \
  -c "{\"function\":\"RecordEvent\",\"Args\":[\"$ID\",\"pi-01\",\"$TS\",\"AF\",\"0.93\",\"$HASH\"]}"

sleep 3
for p in hospital0 hospital1 clinic0 clinic1; do
  set_peer "$p"
  echo "== $CORE_PEER_ADDRESS"
  peer chaincode query -C "$CHANNEL" -n "$CC_NAME" -c "{\"function\":\"GetEvent\",\"Args\":[\"$ID\"]}"
done

set_peer clinic1
echo -n "VerifyHash(correct): ";  peer chaincode query -C "$CHANNEL" -n "$CC_NAME" -c "{\"function\":\"VerifyHash\",\"Args\":[\"$ID\",\"$HASH\"]}"
echo -n "VerifyHash(tampered): "; peer chaincode query -C "$CHANNEL" -n "$CC_NAME" -c "{\"function\":\"VerifyHash\",\"Args\":[\"$ID\",\"$(echo -n x | sha256sum | cut -d' ' -f1)\"]}"

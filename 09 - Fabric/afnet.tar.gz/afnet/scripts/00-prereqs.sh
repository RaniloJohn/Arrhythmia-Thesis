#!/usr/bin/env bash
# Run on EACH Mint:  bash scripts/00-prereqs.sh <1|2|3|4>
# Static IP, /etc/hosts, Docker, Fabric 2.5.15 binaries/images, Tailscale, firewall.
set -euo pipefail
N="${1:?usage: 00-prereqs.sh <node number 1-4>}"
[[ "$N" =~ ^[1-4]$ ]] || { echo "node must be 1-4"; exit 1; }
AFNET="$(cd "$(dirname "$0")/.." && pwd)"
IP="192.168.68.11$((N-1))"
GW="192.168.68.1"

echo "== hostname + static IP ($IP)"
sudo hostnamectl set-hostname "mint${N}"
CON="$(nmcli -t -f NAME,TYPE con show --active | awk -F: '$2=="802-3-ethernet"{print $1; exit}')"
if [[ -n "$CON" ]]; then
  sudo nmcli con mod "$CON" ipv4.method manual ipv4.addresses "$IP/24" \
       ipv4.gateway "$GW" ipv4.dns "$GW 1.1.1.1"
  sudo nmcli con up "$CON" || true
else
  echo "!! no active wired connection — set $IP/24 gw $GW manually"
fi

echo "== /etc/hosts"
sudo sed -i '/# --- afnet (Mints) ---/,/peer1.clinic.af.local/d' /etc/hosts
cat "$AFNET/common/hosts.lan" | sudo tee -a /etc/hosts >/dev/null

echo "== packages + Docker"
sudo apt-get update
sudo apt-get install -y ca-certificates curl git jq gnupg ufw sqlite3 golang-go
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor --yes -o /etc/apt/keyrings/docker.gpg
CODENAME="$(. /etc/os-release; echo "${UBUNTU_CODENAME}")"
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu ${CODENAME} stable" \
  | sudo tee /etc/apt/sources.list.d/docker.list >/dev/null
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
sudo usermod -aG docker "$USER"

echo "== Fabric 2.5.15 binaries + images"
cd "$AFNET"
[[ -f install-fabric.sh ]] || curl -sSLO https://raw.githubusercontent.com/hyperledger/fabric/main/scripts/install-fabric.sh
chmod +x install-fabric.sh
sudo ./install-fabric.sh --fabric-version 2.5.15 docker binary
sudo chown -R "$USER:$USER" "$AFNET"
sudo docker pull hyperledger/fabric-ccenv:2.5
sudo docker pull hyperledger/fabric-baseos:2.5
grep -q 'afnet/scripts/env.sh' ~/.bashrc || echo "source $AFNET/scripts/env.sh" >> ~/.bashrc

echo "== Tailscale"
command -v tailscale >/dev/null || curl -fsSL https://tailscale.com/install.sh | sh
echo "   run later: sudo tailscale up --advertise-tags=tag:fabric"

echo "== firewall"
sudo ufw allow OpenSSH
sudo ufw allow from 192.168.68.0/24 to any port 7050:7053 proto tcp
sudo ufw allow from 192.168.68.0/24 to any port 9443:9444 proto tcp
sudo ufw allow in on tailscale0 to any port 7051 proto tcp
sudo ufw --force enable

echo "== done on mint${N}. Log out/in (docker group), then: sudo tailscale up --advertise-tags=tag:fabric"

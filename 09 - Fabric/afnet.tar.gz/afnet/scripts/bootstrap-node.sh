#!/usr/bin/env bash
# One-shot node setup. Run ON the node:  bash ~/afnet/scripts/bootstrap-node.sh <1|2|3|4>
# Idempotent: safe to re-run. Log: ~/afnet/setup-mintN.log
#  - hosts, Docker (+compose), Fabric 2.5.15 binaries/images, Tailscale (installed, not logged in), ufw
#  - node 1: generates crypto + genesis block (first run only)
#  - systemd afnet.service -> containers start on every boot; joins channel (node 1 now, others via mint1)
set -euo pipefail
N="${1:?usage: bootstrap-node.sh <1|2|3|4>}"
[[ "$N" =~ ^[1-4]$ ]] || { echo "node must be 1-4"; exit 1; }
AFNET="$(cd "$(dirname "$0")/.." && pwd)"
NODE="mint${N}"
LAN="192.168.68.0/24"
LOG="$AFNET/setup-${NODE}.log"
exec > >(tee -a "$LOG") 2>&1
step() { echo; echo "===== [$(date +%T)] $*"; }
ok()   { echo "  OK: $*"; }

step "afnet bootstrap: $NODE on $(hostname) ($(hostname -I 2>/dev/null | awk '{print $1}'))"
sudo -v
( while kill -0 $$ 2>/dev/null; do sudo -n true; sleep 50; done ) 2>/dev/null &

step "/etc/hosts"
sudo sed -i '/# --- afnet (Mints) ---/,/peer1.clinic.af.local/d' /etc/hosts
sudo tee -a /etc/hosts >/dev/null < "$AFNET/common/hosts.lan"
getent hosts orderer1.orderer.af.local && ok hosts

step "Wi-Fi power saving off (prevents dropped peers)"
sudo mkdir -p /etc/NetworkManager/conf.d
printf '[connection]\nwifi.powersave = 2\n' | sudo tee /etc/NetworkManager/conf.d/afnet-wifi-powersave.conf >/dev/null
ok "applies on next reconnect/boot"

step "base packages"
sudo apt-get update -qq
sudo apt-get install -y -qq ca-certificates curl git jq gnupg ufw sqlite3 >/dev/null
ok packages

step "Docker"
if ! command -v docker >/dev/null; then
  sudo install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor --yes -o /etc/apt/keyrings/docker.gpg
  CODENAME="$(. /etc/os-release; echo "${UBUNTU_CODENAME}")"
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu ${CODENAME} stable" \
    | sudo tee /etc/apt/sources.list.d/docker.list >/dev/null
  sudo apt-get update -qq
  sudo apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-compose-plugin >/dev/null
fi
if ! sudo docker compose version >/dev/null 2>&1; then
  sudo apt-get install -y -qq docker-compose-plugin >/dev/null 2>&1 \
    || sudo apt-get install -y -qq docker-compose-v2 >/dev/null
fi
sudo systemctl enable --now docker containerd >/dev/null 2>&1 || sudo systemctl enable --now docker
sudo usermod -aG docker "$USER"
sudo docker --version; sudo docker compose version

step "Fabric 2.5.15 binaries + images"
cd "$AFNET"
[[ -f install-fabric.sh ]] || curl -sSLO https://raw.githubusercontent.com/hyperledger/fabric/main/scripts/install-fabric.sh
chmod +x install-fabric.sh
if [[ ! -x bin/peer ]] || ! bin/peer version 2>/dev/null | grep -q 'Version: v\?2.5.15'; then
  ./install-fabric.sh --fabric-version 2.5.15 binary
fi
for img in fabric-peer:2.5.15 fabric-orderer:2.5.15 fabric-ccenv:2.5 fabric-baseos:2.5; do
  sudo docker image inspect "hyperledger/$img" >/dev/null 2>&1 || sudo docker pull -q "hyperledger/$img"
done
bin/peer version | head -2
grep -q 'afnet/scripts/env.sh' ~/.bashrc || echo "source $AFNET/scripts/env.sh" >> ~/.bashrc
ok fabric

step "Tailscale (install only; login later: sudo tailscale up --advertise-tags=tag:fabric)"
command -v tailscale >/dev/null || curl -fsSL https://tailscale.com/install.sh | sh
sudo systemctl enable --now tailscaled >/dev/null 2>&1 || true
ok tailscale

step "firewall"
sudo ufw allow OpenSSH >/dev/null
sudo ufw allow from "$LAN" to any port 7050:7053 proto tcp >/dev/null
sudo ufw allow from "$LAN" to any port 9443:9444 proto tcp >/dev/null
sudo ufw allow in on tailscale0 to any port 7051 proto tcp >/dev/null 2>&1 || true
sudo ufw --force enable >/dev/null
sudo ufw status | head -12

source "$AFNET/scripts/env.sh"
if [[ "$N" == 1 && ! -d "$AFNET/organizations" ]]; then
  step "crypto + genesis (node 1, first run)"
  bash "$AFNET/scripts/01-gen-crypto-and-genesis.sh"
fi

step "check this node's certificates"
O=organizations/ordererOrganizations/orderer.af.local/orderers
P=organizations/peerOrganizations
need=()
case "$N" in
  1) need=("$O/orderer1.orderer.af.local" "$P/hospital.af.local/peers/peer0.hospital.af.local") ;;
  2) need=("$O/orderer2.orderer.af.local" "$P/hospital.af.local/peers/peer1.hospital.af.local") ;;
  3) need=("$O/orderer3.orderer.af.local" "$P/clinic.af.local/peers/peer0.clinic.af.local") ;;
  4) need=("$P/clinic.af.local/peers/peer1.clinic.af.local") ;;
esac
for d in "${need[@]}"; do
  [[ -d "$AFNET/$d" ]] || { echo "  MISSING $d -> on mint1 run: bash scripts/02-distribute.sh $USER"; exit 2; }
done
ok certs

step "systemd: start Fabric on every boot"
sed "s#__NODE__#$NODE#g; s#__AFNET__#$AFNET#g" "$AFNET/common/afnet.service" | sudo tee /etc/systemd/system/afnet.service >/dev/null
sudo systemctl daemon-reload
sudo systemctl enable afnet.service >/dev/null
sudo systemctl restart afnet.service
sudo systemctl is-enabled afnet.service docker
sudo docker compose -f "$NODE/compose.yaml" ps

step "wait for ports"
wait_port() { for _ in $(seq 1 60); do (echo > "/dev/tcp/127.0.0.1/$1") 2>/dev/null && return 0; sleep 2; done; return 1; }
[[ "$N" != 4 ]] && { wait_port 7053 && ok "orderer admin 7053"; }
wait_port 7051 && ok "peer 7051"

if [[ "$N" == 1 ]]; then
  step "join channel (orderer1 + peer0.hospital)"
  BLOCK="channel-artifacts/${CHANNEL}.block"
  if osnadmin channel list -o orderer1.orderer.af.local:7053 --ca-file "$ORDERER_CA" \
       --client-cert "$ORDERER_ADMIN_TLS_CERT" --client-key "$ORDERER_ADMIN_TLS_KEY" 2>/dev/null | grep -q "\"$CHANNEL\""; then
    ok "orderer1 already in $CHANNEL"
  else
    osnadmin channel join --channelID "$CHANNEL" --config-block "$BLOCK" -o orderer1.orderer.af.local:7053 \
      --ca-file "$ORDERER_CA" --client-cert "$ORDERER_ADMIN_TLS_CERT" --client-key "$ORDERER_ADMIN_TLS_KEY"
  fi
  set_peer hospital0
  if peer channel list 2>/dev/null | grep -qx "$CHANNEL"; then
    ok "peer0.hospital already in $CHANNEL"
  else
    peer channel join -b "$BLOCK"
  fi
  peer channel getinfo -c "$CHANNEL" || true
fi

step "DONE ($NODE). Reboot test: sudo reboot  ->  after boot: docker ps"
echo "Note: Raft needs 2 of 3 orderers up before transactions commit (mint1+mint2 or mint1+mint3)."

#!/usr/bin/env bash
# mint1 only. Generates all MSP/TLS material and the afchannel genesis block.
set -euo pipefail
source "$(dirname "$0")/env.sh"
cd "$AFNET"

if [[ -d organizations ]]; then
  echo "organizations/ exists — delete it first to regenerate (this invalidates the running network)"; exit 1
fi

cryptogen generate --config=common/crypto-config.yaml --output=organizations
mkdir -p channel-artifacts
configtxgen -configPath common -profile AFChannel -channelID "$CHANNEL" \
  -outputBlock "channel-artifacts/${CHANNEL}.block"
configtxgen -inspectBlock "channel-artifacts/${CHANNEL}.block" | jq '.data.data[0].payload.header.channel_header.channel_id'
echo "OK: organizations/ + channel-artifacts/${CHANNEL}.block"

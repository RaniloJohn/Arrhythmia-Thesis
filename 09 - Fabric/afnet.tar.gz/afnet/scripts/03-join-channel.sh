#!/usr/bin/env bash
# mint1 only, after `docker compose up -d` on all 4 Mints.
set -euo pipefail
source "$(dirname "$0")/env.sh"
cd "$AFNET"
BLOCK="channel-artifacts/${CHANNEL}.block"

echo "== orderers join (channel participation API)"
for n in 1 2 3; do
  osnadmin channel join --channelID "$CHANNEL" --config-block "$BLOCK" \
    -o "orderer${n}.orderer.af.local:7053" \
    --ca-file "$ORDERER_CA" --client-cert "$ORDERER_ADMIN_TLS_CERT" --client-key "$ORDERER_ADMIN_TLS_KEY" \
    || echo "   (orderer${n} may already be joined)"
done
sleep 5
osnadmin channel list --channelID "$CHANNEL" -o orderer1.orderer.af.local:7053 \
  --ca-file "$ORDERER_CA" --client-cert "$ORDERER_ADMIN_TLS_CERT" --client-key "$ORDERER_ADMIN_TLS_KEY"

echo "== peers join"
for p in hospital0 hospital1 clinic0 clinic1; do
  set_peer "$p"
  peer channel join -b "$BLOCK" || echo "   ($p may already be joined)"
done
sleep 3
for p in hospital0 hospital1 clinic0 clinic1; do
  set_peer "$p"; echo -n "$CORE_PEER_ADDRESS: "; peer channel getinfo -c "$CHANNEL"
done

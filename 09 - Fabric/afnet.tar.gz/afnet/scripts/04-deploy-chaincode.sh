#!/usr/bin/env bash
# mint1 only.  bash scripts/04-deploy-chaincode.sh [version] [sequence]
# Upgrade: bump both, e.g. 04-deploy-chaincode.sh 1.1 2
set -euo pipefail
VER="${1:-1.0}"
SEQ="${2:-1}"
source "$(dirname "$0")/env.sh"
cd "$AFNET"

echo "== vendor + package"
( cd chaincode/afevents && go mod tidy && go mod vendor )
PKG="${CC_NAME}_${VER}.tar.gz"
peer lifecycle chaincode package "$PKG" --path chaincode/afevents --lang golang --label "${CC_NAME}_${VER}"
PKG_ID="$(peer lifecycle chaincode calculatepackageid "$PKG")"
echo "   package id: $PKG_ID"

echo "== install on all 4 peers (first build takes a few minutes)"
for p in hospital0 hospital1 clinic0 clinic1; do
  set_peer "$p"
  if peer lifecycle chaincode queryinstalled --output json | jq -e --arg id "$PKG_ID" \
       '.installed_chaincodes[]? | select(.package_id==$id)' >/dev/null; then
    echo "   $p: already installed"
  else
    peer lifecycle chaincode install "$PKG"
  fi
done

echo "== approve (one per org)"
for p in hospital0 clinic0; do
  set_peer "$p"
  peer lifecycle chaincode approveformyorg -o "$ORDERER" --tls --cafile "$ORDERER_CA" \
    --channelID "$CHANNEL" --name "$CC_NAME" --version "$VER" --package-id "$PKG_ID" --sequence "$SEQ"
done

set_peer hospital0
peer lifecycle chaincode checkcommitreadiness --channelID "$CHANNEL" --name "$CC_NAME" \
  --version "$VER" --sequence "$SEQ" --output json

echo "== commit"
peer lifecycle chaincode commit -o "$ORDERER" --tls --cafile "$ORDERER_CA" \
  --channelID "$CHANNEL" --name "$CC_NAME" --version "$VER" --sequence "$SEQ" "${ENDORSERS[@]}"
peer lifecycle chaincode querycommitted --channelID "$CHANNEL" --name "$CC_NAME"

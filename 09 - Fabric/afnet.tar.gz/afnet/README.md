# afnet — Hyperledger Fabric 2.5.15 for AF detection thesis

2 orgs (Hospital, Clinic) · 4 peers · 3-node Raft · channel `afchannel` · chaincode `afevents` (Go)
Pi reaches the ledger from any network over Tailscale; only peer port 7051 exposed to it.

| Host  | LAN IP       | Runs |
|-------|--------------|------|
| mint1 | 192.168.68.110| orderer1, peer0.hospital, **admin CLI (all scripts)** |
| mint2 | 192.168.68.111| orderer2, peer1.hospital |
| mint3 | 192.168.68.112| orderer3, peer0.clinic |
| mint4 | 192.168.68.113| peer1.clinic |
| Pi    | Tailscale    | af-gateway (Node) + af-sync (Python) |

Router 192.168.68.1 · nodes static .110–.113 (keep outside DHCP pool).

## Order of operations

```bash
# 0. copy this folder to ~/afnet on ALL 4 Mints (USB/scp/git)
bash scripts/00-prereqs.sh <1|2|3|4>        # each Mint; log out/in after
sudo tailscale up --advertise-tags=tag:fabric   # each Mint
# Tailscale admin console: paste common/tailscale-acl.json; disable key expiry on all 5 machines

# 1. mint1
bash scripts/01-gen-crypto-and-genesis.sh
bash scripts/02-distribute.sh <ssh-user>    # pushes each host only its own certs

# 2. each Mint (from ~/afnet)
docker compose -f mintN/compose.yaml up -d

# 3. mint1
bash scripts/03-join-channel.sh             # 3 orderers + 4 peers join
bash scripts/04-deploy-chaincode.sh         # upgrade later: 04-deploy-chaincode.sh 1.1 2
bash scripts/05-smoke-test.sh               # write + read from all 4 peers + verify
bash scripts/06-export-pi-identity.sh       # -> pi-identity.tar.gz

# 4. Pi (Raspberry Pi OS 64-bit)
#    copy pi/ folder + pi-identity.tar.gz to ~ ; fill pi/hosts.tailscale with `tailscale ip -4` of each Mint
bash pi/setup_pi.sh
curl -s 127.0.0.1:3001/health
```

## Pi integration (from the ML pipeline)

```python
from af_ledger import Ledger
led = Ledger()
led.record_event("pi-01", "AF", 0.93, ppg_window, fs=100)   # SQLite + SHA-256; af-sync pushes when online
```
CLI: `python3 af_ledger.py status | verify <id> | verify-all | demo | tamper <id>`

## Panel demos
- **Fault tolerance:** on mint2 `bash scripts/90-raft-failover-demo.sh stop` → smoke test still commits. Stop a 2nd orderer → writes halt.
- **Peer failover:** stop peer0.hospital → Pi gateway switches to peer1.hospital automatically.
- **Offline-first:** disconnect Pi → events stay `pending` → reconnect → synced in order.
- **Tamper detection:** `af_ledger.py demo` → wait for sync → `tamper <id>` → `verify <id>` = TAMPERED.

## Notes
- `fabric-contract-api-go` pinned to v2.2.1: v2.2.3+ require Go ≥ 1.26.7, newer than the Go in `fabric-ccenv:2.5`. Do not bump without checking.
- Deploy script vendors Go deps so the peer's chaincode build needs no internet.
- Endorsement = MAJORITY → every event endorsed by Hospital AND Clinic.
- Only hashes + metadata on-chain; raw PPG stays in the Pi's SQLite (data privacy).
- cryptogen = lab PKI. Production would use Fabric CA per org.
- Pi has no RTC → fit a DS3231; TLS and event timestamps depend on correct time.
- Reset everything: `docker compose -f mintN/compose.yaml down -v` on each Mint, delete `organizations/` and `channel-artifacts/` on mint1.

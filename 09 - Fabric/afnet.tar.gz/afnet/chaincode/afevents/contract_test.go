package main

import (
	"github.com/hyperledger/fabric-chaincode-go/v2/pkg/cid"
	"github.com/hyperledger/fabric-chaincode-go/v2/shim"
	"github.com/hyperledger/fabric-contract-api-go/v2/contractapi"
	"github.com/hyperledger/fabric-protos-go-apiv2/ledger/queryresult"
	"google.golang.org/protobuf/types/known/timestamppb"
	"sort"
	"strings"
	"testing"
)

type stub struct {
	shim.ChaincodeStubInterface
	st map[string][]byte
}

func (s *stub) GetState(k string) ([]byte, error)               { return s.st[k], nil }
func (s *stub) PutState(k string, v []byte) error               { s.st[k] = v; return nil }
func (s *stub) GetTxID() string                                 { return "tx1" }
func (s *stub) GetTxTimestamp() (*timestamppb.Timestamp, error) { return timestamppb.Now(), nil }
func (s *stub) SetEvent(string, []byte) error                   { return nil }
func (s *stub) CreateCompositeKey(o string, a []string) (string, error) {
	return shim.CreateCompositeKey(o, a)
}
func (s *stub) SplitCompositeKey(k string) (string, []string, error) {
	p := strings.Split(strings.Trim(k, "\x00"), "\x00")
	return p[0], p[1:], nil
}

type it struct {
	ks []string
	s  *stub
	i  int
}

func (x *it) HasNext() bool { return x.i < len(x.ks) }
func (x *it) Next() (*queryresult.KV, error) {
	k := x.ks[x.i]
	x.i++
	return &queryresult.KV{Key: k, Value: x.s.st[k]}, nil
}
func (x *it) Close() error { return nil }
func (s *stub) GetStateByPartialCompositeKey(o string, a []string) (shim.StateQueryIteratorInterface, error) {
	pre, _ := shim.CreateCompositeKey(o, a)
	var ks []string
	for k := range s.st {
		if strings.HasPrefix(k, pre) {
			ks = append(ks, k)
		}
	}
	sort.Strings(ks)
	return &it{ks: ks, s: s}, nil
}

type ci struct {
	cid.ClientIdentity
	msp string
}

func (c ci) GetMSPID() (string, error) { return c.msp, nil }
func (c ci) GetID() (string, error)    { return "x509::CN=User1", nil }
func ctx(msp string, s *stub) contractapi.TransactionContextInterface {
	c := &contractapi.TransactionContext{}
	c.SetStub(s)
	c.SetClientIdentity(ci{msp: msp})
	return c
}

const H = "9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08"

func TestFlow(t *testing.T) {
	s := &stub{st: map[string][]byte{}}
	c := &AFContract{}
	if _, err := c.RecordEvent(ctx("ClinicMSP", s), "e1", "pi-01", "2026-10-27T06:00:00.123Z", "AF", "0.9", H); err == nil {
		t.Fatal("clinic should be denied")
	}
	ev, err := c.RecordEvent(ctx("HospitalMSP", s), "e1", "pi-01", "2026-10-27T06:00:00.123Z", "af", "0.9", strings.ToUpper(H))
	if err != nil {
		t.Fatal(err)
	}
	if ev.Label != "AF" || ev.RecordHash != H {
		t.Fatal(ev)
	}
	if _, err := c.RecordEvent(ctx("HospitalMSP", s), "e1", "pi-01", "2026-10-27T06:00:00Z", "AF", "0.9", H); err == nil {
		t.Fatal("dup allowed")
	}
	for _, bad := range [][]string{{"e2", "pi", "bad", "AF", "0.9", H}, {"e2", "pi", "2026-10-27T06:00:00Z", "X", "0.9", H}, {"e2", "pi", "2026-10-27T06:00:00Z", "AF", "1.5", H}, {"e2", "pi", "2026-10-27T06:00:00Z", "AF", "0.5", "abc"}} {
		if _, err := c.RecordEvent(ctx("HospitalMSP", s), bad[0], bad[1], bad[2], bad[3], bad[4], bad[5]); err == nil {
			t.Fatal("accepted", bad)
		}
	}
	c.RecordEvent(ctx("HospitalMSP", s), "e3", "pi-01", "2026-10-27T07:00:00Z", "NON_AF", "0.2", H)
	c.RecordEvent(ctx("HospitalMSP", s), "e4", "pi-02", "2026-10-27T07:00:00Z", "AF", "0.7", H)
	v, _ := c.VerifyHash(ctx("ClinicMSP", s), "e1", H)
	if !v.Match {
		t.Fatal("verify")
	}
	v, _ = c.VerifyHash(ctx("ClinicMSP", s), "e1", strings.Repeat("0", 64))
	if v.Match || !v.Exists {
		t.Fatal("tamper")
	}
	v, _ = c.VerifyHash(ctx("ClinicMSP", s), "nope", H)
	if v.Exists {
		t.Fatal("exists")
	}
	l, err := c.QueryByDevice(ctx("ClinicMSP", s), "pi-01")
	if err != nil || len(l) != 2 {
		t.Fatal("bydevice", len(l), err)
	}
	if ok, _ := c.EventExists(ctx("ClinicMSP", s), "e4"); !ok {
		t.Fatal("exists e4")
	}
	if _, err := c.GetEvent(ctx("ClinicMSP", s), "zz"); err == nil {
		t.Fatal("get missing")
	}
}
func TestMetadata(t *testing.T) {
	if _, err := contractapi.NewChaincode(&AFContract{}); err != nil {
		t.Fatal(err)
	}
}

package main

import (
	"log"

	"github.com/hyperledger/fabric-contract-api-go/v2/contractapi"
)

func main() {
	cc, err := contractapi.NewChaincode(&AFContract{})
	if err != nil {
		log.Panicf("create afevents chaincode: %v", err)
	}
	cc.Info.Title = "afevents"
	cc.Info.Version = "1.0"
	if err := cc.Start(); err != nil {
		log.Panicf("start afevents chaincode: %v", err)
	}
}

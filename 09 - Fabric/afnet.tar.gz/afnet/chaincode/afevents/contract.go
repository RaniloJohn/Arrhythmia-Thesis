package main

import (
	"encoding/hex"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/hyperledger/fabric-contract-api-go/v2/contractapi"
)

const (
	docType      = "afevent"
	deviceIndex  = "device~event"
	writerMSP    = "HospitalMSP" // edge devices + dashboard enrol under Hospital
	maxIDLength  = 128
	hashHexBytes = 32
)

// AFEvent is the on-chain record. Raw PPG never goes on-chain; RecordHash is the
// SHA-256 of the canonical off-chain record (metadata + PPG waveform digest) kept in the Pi's SQLite.
type AFEvent struct {
	DocType      string  `json:"docType"`
	EventID      string  `json:"eventId"`
	DeviceID     string  `json:"deviceId"`
	Timestamp    string  `json:"timestamp"` // device clock, RFC3339 UTC
	Label        string  `json:"label"`     // AF | NON_AF
	Confidence   float64 `json:"confidence"`
	RecordHash   string  `json:"recordHash"` // hex SHA-256
	SubmitterMSP string  `json:"submitterMsp"`
	SubmitterID  string  `json:"submitterId"`
	TxID         string  `json:"txId"`
	LedgerTime   string  `json:"ledgerTime"` // tx timestamp, RFC3339 UTC
}

type HistoryEntry struct {
	TxID      string   `json:"txId"`
	Timestamp string   `json:"timestamp"`
	IsDelete  bool     `json:"isDelete"`
	Value     *AFEvent `json:"value,omitempty"`
}

type VerifyResult struct {
	EventID    string `json:"eventId"`
	Exists     bool   `json:"exists"`
	Match      bool   `json:"match"`
	LedgerHash string `json:"ledgerHash,omitempty"`
	TxID       string `json:"txId,omitempty"`
}

type AFContract struct {
	contractapi.Contract
}

func validID(field, v string) error {
	if v == "" || len(v) > maxIDLength {
		return fmt.Errorf("%s must be 1-%d chars", field, maxIDLength)
	}
	if strings.ContainsAny(v, "\x00\u0000") {
		return fmt.Errorf("%s contains invalid characters", field)
	}
	return nil
}

func normHash(h string) (string, error) {
	h = strings.ToLower(strings.TrimSpace(h))
	b, err := hex.DecodeString(h)
	if err != nil || len(b) != hashHexBytes {
		return "", fmt.Errorf("recordHash must be 64 hex chars (SHA-256)")
	}
	return h, nil
}

// RecordEvent writes an immutable event. Re-submitting an existing eventId fails (no overwrite).
func (c *AFContract) RecordEvent(ctx contractapi.TransactionContextInterface,
	eventID, deviceID, timestamp, label, confidence, recordHash string) (*AFEvent, error) {

	stub := ctx.GetStub()
	cid := ctx.GetClientIdentity()

	msp, err := cid.GetMSPID()
	if err != nil {
		return nil, err
	}
	if msp != writerMSP {
		return nil, fmt.Errorf("access denied: %s may not record events", msp)
	}
	for f, v := range map[string]string{"eventId": eventID, "deviceId": deviceID} {
		if err := validID(f, v); err != nil {
			return nil, err
		}
	}
	// Validate only; store the device's string verbatim so it matches the off-chain record.
	if _, err := time.Parse(time.RFC3339Nano, timestamp); err != nil {
		return nil, fmt.Errorf("timestamp must be RFC3339: %v", err)
	}
	label = strings.ToUpper(label)
	if label != "AF" && label != "NON_AF" {
		return nil, fmt.Errorf("label must be AF or NON_AF")
	}
	conf, err := strconv.ParseFloat(confidence, 64)
	if err != nil || conf < 0 || conf > 1 {
		return nil, fmt.Errorf("confidence must be a number in [0,1]")
	}
	hash, err := normHash(recordHash)
	if err != nil {
		return nil, err
	}

	existing, err := stub.GetState(eventID)
	if err != nil {
		return nil, err
	}
	if existing != nil {
		return nil, fmt.Errorf("event %s already exists", eventID)
	}

	txTs, err := stub.GetTxTimestamp()
	if err != nil {
		return nil, err
	}
	submitter, _ := cid.GetID()

	ev := &AFEvent{
		DocType:      docType,
		EventID:      eventID,
		DeviceID:     deviceID,
		Timestamp:    timestamp,
		Label:        label,
		Confidence:   conf,
		RecordHash:   hash,
		SubmitterMSP: msp,
		SubmitterID:  submitter,
		TxID:         stub.GetTxID(),
		LedgerTime:   txTs.AsTime().UTC().Format(time.RFC3339Nano),
	}
	b, err := json.Marshal(ev)
	if err != nil {
		return nil, err
	}
	if err := stub.PutState(eventID, b); err != nil {
		return nil, err
	}
	idx, err := stub.CreateCompositeKey(deviceIndex, []string{deviceID, eventID})
	if err != nil {
		return nil, err
	}
	if err := stub.PutState(idx, []byte{0x00}); err != nil {
		return nil, err
	}
	payload, _ := json.Marshal(map[string]string{"eventId": eventID, "deviceId": deviceID, "label": label})
	if err := stub.SetEvent("AFEventRecorded", payload); err != nil {
		return nil, err
	}
	return ev, nil
}

func (c *AFContract) GetEvent(ctx contractapi.TransactionContextInterface, eventID string) (*AFEvent, error) {
	b, err := ctx.GetStub().GetState(eventID)
	if err != nil {
		return nil, err
	}
	if b == nil {
		return nil, fmt.Errorf("event %s not found", eventID)
	}
	var ev AFEvent
	if err := json.Unmarshal(b, &ev); err != nil {
		return nil, err
	}
	return &ev, nil
}

func (c *AFContract) EventExists(ctx contractapi.TransactionContextInterface, eventID string) (bool, error) {
	b, err := ctx.GetStub().GetState(eventID)
	return b != nil, err
}

// VerifyHash compares a locally recomputed SHA-256 against the ledger copy (tamper check).
func (c *AFContract) VerifyHash(ctx contractapi.TransactionContextInterface, eventID, recordHash string) (*VerifyResult, error) {
	res := &VerifyResult{EventID: eventID}
	b, err := ctx.GetStub().GetState(eventID)
	if err != nil {
		return nil, err
	}
	if b == nil {
		return res, nil
	}
	var ev AFEvent
	if err := json.Unmarshal(b, &ev); err != nil {
		return nil, err
	}
	h, err := normHash(recordHash)
	res.Exists, res.LedgerHash, res.TxID = true, ev.RecordHash, ev.TxID
	res.Match = err == nil && h == ev.RecordHash
	return res, nil
}

func (c *AFContract) GetHistory(ctx contractapi.TransactionContextInterface, eventID string) ([]*HistoryEntry, error) {
	it, err := ctx.GetStub().GetHistoryForKey(eventID)
	if err != nil {
		return nil, err
	}
	defer it.Close()
	out := []*HistoryEntry{}
	for it.HasNext() {
		m, err := it.Next()
		if err != nil {
			return nil, err
		}
		e := &HistoryEntry{TxID: m.TxId, IsDelete: m.IsDelete}
		if m.Timestamp != nil {
			e.Timestamp = m.Timestamp.AsTime().UTC().Format(time.RFC3339Nano)
		}
		if len(m.Value) > 0 {
			var ev AFEvent
			if json.Unmarshal(m.Value, &ev) == nil {
				e.Value = &ev
			}
		}
		out = append(out, e)
	}
	return out, nil
}

// QueryByDevice lists all events for one wearable/edge device.
func (c *AFContract) QueryByDevice(ctx contractapi.TransactionContextInterface, deviceID string) ([]*AFEvent, error) {
	stub := ctx.GetStub()
	it, err := stub.GetStateByPartialCompositeKey(deviceIndex, []string{deviceID})
	if err != nil {
		return nil, err
	}
	defer it.Close()
	out := []*AFEvent{}
	for it.HasNext() {
		kv, err := it.Next()
		if err != nil {
			return nil, err
		}
		_, parts, err := stub.SplitCompositeKey(kv.Key)
		if err != nil || len(parts) != 2 {
			continue
		}
		ev, err := c.GetEvent(ctx, parts[1])
		if err == nil {
			out = append(out, ev)
		}
	}
	return out, nil
}

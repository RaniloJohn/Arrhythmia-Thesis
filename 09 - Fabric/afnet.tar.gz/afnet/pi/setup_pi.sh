#!/usr/bin/env bash
# Run on the Raspberry Pi (Raspberry Pi OS 64-bit), from the copied pi/ folder:
#   bash setup_pi.sh
# Needs: ~/pi-identity.tar.gz (from mint1: scripts/06-export-pi-identity.sh) and hosts.tailscale filled in.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
APP="$HOME/af-edge"

echo "== packages (Node 22 LTS, sqlite, chrony, i2c for DS3231 RTC)"
sudo apt-get update
sudo apt-get install -y ca-certificates curl sqlite3 chrony i2c-tools python3
if ! command -v node >/dev/null || [[ "$(node -v | cut -d. -f1 | tr -d v)" -lt 18 ]]; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
  sudo apt-get install -y nodejs
fi

echo "== app files -> $APP"
mkdir -p "$APP/identity"
cp -r "$HERE/gateway" "$APP/"
cp "$HERE/af_ledger.py" "$APP/"
( cd "$APP/gateway" && npm ci --omit=dev || npm install --omit=dev )
if [[ -f "$HOME/pi-identity.tar.gz" ]]; then
  tar xzf "$HOME/pi-identity.tar.gz" -C "$APP/identity"
fi
chmod 700 "$APP/identity"; chmod 600 "$APP/identity/key.pem" 2>/dev/null || echo "!! identity missing: put pi-identity.tar.gz in ~ and rerun"

echo "== /etc/hosts (Fabric hostnames -> Tailscale IPs)"
if grep -q '^100\.x' "$HERE/hosts.tailscale"; then
  echo "!! edit hosts.tailscale with real 100.x IPs first (tailscale ip -4 on each Mint)"; exit 1
fi
sudo sed -i '/# --- afnet (tailscale) ---/,/# --- end afnet ---/d' /etc/hosts
cat "$HERE/hosts.tailscale" | sudo tee -a /etc/hosts >/dev/null

echo "== Tailscale"
command -v tailscale >/dev/null || curl -fsSL https://tailscale.com/install.sh | sh
sudo tailscale status >/dev/null 2>&1 || sudo tailscale up --advertise-tags=tag:edge

echo "== DS3231 RTC overlay (takes effect after reboot)"
CFG=/boot/firmware/config.txt; [[ -f $CFG ]] || CFG=/boot/config.txt
grep -q 'i2c-rtc,ds3231' "$CFG" || echo 'dtoverlay=i2c-rtc,ds3231' | sudo tee -a "$CFG" >/dev/null
sudo raspi-config nonint do_i2c 0 || true

echo "== systemd services"
for u in af-gateway af-sync; do
  sed "s#__USER__#$USER#g; s#__APP__#$APP#g" "$HERE/systemd/$u.service" | sudo tee "/etc/systemd/system/$u.service" >/dev/null
done
sudo systemctl daemon-reload
sudo systemctl enable --now af-gateway af-sync

echo "== done. Check:  curl -s 127.0.0.1:3001/health ; journalctl -fu af-sync"
echo "   Reboot once to activate the RTC, then: sudo hwclock -r"

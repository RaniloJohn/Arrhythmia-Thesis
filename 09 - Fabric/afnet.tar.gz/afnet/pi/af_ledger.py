#!/usr/bin/env python3
"""
AF edge ledger module (Raspberry Pi). Stdlib only.

Pipeline use:
    from af_ledger import Ledger
    led = Ledger()                                  # opens/creates SQLite
    led.record_event("pi-01", "AF", 0.93, ppg_samples, fs=100)   # called by classifier

CLI:
    python3 af_ledger.py sync            # run sync worker (systemd uses this)
    python3 af_ledger.py status          # counts pending/synced/failed
    python3 af_ledger.py verify <id>     # recompute hash from SQLite, compare with ledger
    python3 af_ledger.py verify-all
    python3 af_ledger.py demo            # insert a fake AF event (testing)
    python3 af_ledger.py tamper <id>     # PANEL DEMO: alter local record -> verify fails

Flow (Ch.3): detection -> SHA-256 + SQLite (offline-safe) -> deferred sync to Fabric when reachable.
"""
from __future__ import annotations

import array
import hashlib
import json
import os
import random
import sqlite3
import sys
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timezone

DB_PATH = os.environ.get("AF_DB", os.path.expanduser("~/af-edge/af_events.db"))
GATEWAY = os.environ.get("AF_GATEWAY_URL", "http://127.0.0.1:3001")
DEVICE_ID = os.environ.get("AF_DEVICE_ID", "pi-01")
BATCH = int(os.environ.get("AF_SYNC_BATCH", "20"))
IDLE_SLEEP = float(os.environ.get("AF_SYNC_IDLE", "5"))
MAX_BACKOFF = float(os.environ.get("AF_SYNC_MAX_BACKOFF", "300"))

# synced: 0 pending | 1 on ledger | -1 hash conflict with ledger | -2 rejected by chaincode
SCHEMA = """
CREATE TABLE IF NOT EXISTS events (
    event_id     TEXT PRIMARY KEY,
    device_id    TEXT NOT NULL,
    ts           TEXT NOT NULL,          -- RFC3339 UTC, device clock (RTC-backed)
    label        TEXT NOT NULL CHECK (label IN ('AF','NON_AF')),
    confidence   TEXT NOT NULL,          -- fixed 4-dp string, part of the hash
    ppg_fs       INTEGER NOT NULL,
    ppg          BLOB NOT NULL,          -- float32 little-endian samples (off-chain)
    ppg_sha256   TEXT NOT NULL,
    record_hash  TEXT NOT NULL,          -- SHA-256 of canonical record -> on-chain
    synced       INTEGER NOT NULL DEFAULT 0,
    tx_id        TEXT,
    block_number TEXT,
    synced_at    TEXT,
    attempts     INTEGER NOT NULL DEFAULT 0,
    last_error   TEXT
);
CREATE INDEX IF NOT EXISTS idx_events_pending ON events(synced, ts);
"""


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def ppg_to_blob(samples) -> bytes:
    if isinstance(samples, (bytes, bytearray, memoryview)):
        return bytes(samples)
    a = array.array("f", (float(x) for x in samples))
    if sys.byteorder != "little":
        a.byteswap()
    return a.tobytes()


def canonical_record(event_id, device_id, ts, label, confidence, ppg_fs, ppg_sha256) -> bytes:
    """Exact bytes that are hashed. Changing this breaks verification of old records."""
    rec = {
        "v": 1,
        "event_id": event_id,
        "device_id": device_id,
        "timestamp": ts,
        "label": label,
        "confidence": confidence,
        "ppg_fs": int(ppg_fs),
        "ppg_sha256": ppg_sha256,
    }
    return json.dumps(rec, sort_keys=True, separators=(",", ":")).encode("utf-8")


def hash_row(row: sqlite3.Row) -> str:
    """Recompute record hash from what is stored locally (detects local tampering)."""
    ppg_digest = hashlib.sha256(row["ppg"]).hexdigest()
    return hashlib.sha256(canonical_record(
        row["event_id"], row["device_id"], row["ts"], row["label"],
        row["confidence"], row["ppg_fs"], ppg_digest)).hexdigest()


class GatewayDown(Exception):
    pass


def http(method: str, path: str, body: dict | None = None, timeout: float = 90):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(GATEWAY + path, data=data, method=method,
                                 headers={"content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, json.loads(r.read() or b"null")
    except urllib.error.HTTPError as e:
        try:
            payload = json.loads(e.read() or b"null")
        except ValueError:
            payload = None
        if e.code == 503:
            raise GatewayDown(payload)
        return e.code, payload
    except (urllib.error.URLError, ConnectionError, TimeoutError, OSError) as e:
        raise GatewayDown(str(e))


class Ledger:
    def __init__(self, db_path: str = DB_PATH):
        os.makedirs(os.path.dirname(db_path) or ".", exist_ok=True)
        self.db = sqlite3.connect(db_path, timeout=30, isolation_level=None)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.executescript(SCHEMA)

    # ---- called by the ML pipeline -------------------------------------------------
    def record_event(self, device_id: str, label: str, confidence: float, ppg_samples,
                     fs: int, ts: str | None = None, event_id: str | None = None) -> str:
        label = label.upper()
        if label not in ("AF", "NON_AF"):
            raise ValueError("label must be AF or NON_AF")
        if not 0.0 <= float(confidence) <= 1.0:
            raise ValueError("confidence must be in [0,1]")
        event_id = event_id or f"{device_id}-{uuid.uuid4().hex[:16]}"
        ts = ts or utc_now()
        conf = f"{float(confidence):.4f}"
        blob = ppg_to_blob(ppg_samples)
        ppg_sha = hashlib.sha256(blob).hexdigest()
        record_hash = hashlib.sha256(
            canonical_record(event_id, device_id, ts, label, conf, fs, ppg_sha)).hexdigest()
        self.db.execute(
            "INSERT INTO events(event_id,device_id,ts,label,confidence,ppg_fs,ppg,ppg_sha256,record_hash)"
            " VALUES(?,?,?,?,?,?,?,?,?)",
            (event_id, device_id, ts, label, conf, int(fs), blob, ppg_sha, record_hash))
        return event_id

    # ---- sync worker ----------------------------------------------------------------
    def _mark(self, event_id, synced, tx_id=None, block=None, error=None):
        self.db.execute(
            "UPDATE events SET synced=?, tx_id=COALESCE(?,tx_id), block_number=COALESCE(?,block_number),"
            " synced_at=CASE WHEN ?=1 THEN ? ELSE synced_at END, attempts=attempts+1, last_error=?"
            " WHERE event_id=?",
            (synced, tx_id, block, synced, utc_now(), error, event_id))

    def sync_one(self, row: sqlite3.Row) -> None:
        local_hash = hash_row(row)
        if local_hash != row["record_hash"]:
            self._mark(row["event_id"], -1, error="local record altered before sync")
            print(f"[sync] {row['event_id']}: LOCAL TAMPER detected, not submitted", flush=True)
            return
        body = {
            "eventId": row["event_id"], "deviceId": row["device_id"], "timestamp": row["ts"],
            "label": row["label"], "confidence": row["confidence"], "recordHash": row["record_hash"],
        }
        status, resp = http("POST", "/events", body)
        if status == 201:
            self._mark(row["event_id"], 1, resp.get("txId"), resp.get("blockNumber"))
            print(f"[sync] {row['event_id']} -> tx {resp.get('txId')} block {resp.get('blockNumber')}", flush=True)
        elif status == 409:
            # Already on ledger (e.g. crash after commit). Confirm it is OUR record.
            s2, ev = http("GET", f"/events/{urllib.request.quote(row['event_id'])}")
            if s2 == 200 and ev and ev.get("recordHash") == row["record_hash"]:
                self._mark(row["event_id"], 1, ev.get("txId"))
                print(f"[sync] {row['event_id']} already on ledger (tx {ev.get('txId')})", flush=True)
            else:
                self._mark(row["event_id"], -1, error=f"ledger conflict: {resp}")
                print(f"[sync] {row['event_id']} CONFLICT with ledger copy", flush=True)
        elif status == 400:
            self._mark(row["event_id"], -2, error=json.dumps(resp))
            print(f"[sync] {row['event_id']} rejected: {resp}", flush=True)
        else:
            self._mark(row["event_id"], 0, error=f"HTTP {status}: {resp}")
            raise GatewayDown(f"HTTP {status}")

    def run_sync_forever(self) -> None:
        backoff = 2.0
        print(f"[sync] db={DB_PATH} gateway={GATEWAY}", flush=True)
        while True:
            rows = self.db.execute(
                "SELECT * FROM events WHERE synced=0 ORDER BY ts LIMIT ?", (BATCH,)).fetchall()
            if not rows:
                time.sleep(IDLE_SLEEP)
                continue
            try:
                for row in rows:
                    self.sync_one(row)
                backoff = 2.0
            except GatewayDown as e:
                wait = min(backoff, MAX_BACKOFF) * (0.8 + 0.4 * random.random())
                print(f"[sync] ledger unreachable ({e}); {len(rows)}+ pending; retry in {wait:.0f}s", flush=True)
                time.sleep(wait)
                backoff = min(backoff * 2, MAX_BACKOFF)

    # ---- verification ---------------------------------------------------------------
    def verify(self, event_id: str) -> dict:
        row = self.db.execute("SELECT * FROM events WHERE event_id=?", (event_id,)).fetchone()
        if row is None:
            return {"eventId": event_id, "result": "NOT_IN_LOCAL_DB"}
        recomputed = hash_row(row)
        status, res = http("GET", f"/verify?id={urllib.request.quote(event_id)}&hash={recomputed}")
        if status != 200:
            return {"eventId": event_id, "result": "LEDGER_ERROR", "detail": res}
        if not res.get("exists"):
            result = "NOT_ON_LEDGER"
        elif res.get("match"):
            result = "VERIFIED"
        else:
            result = "TAMPERED"
        return {"eventId": event_id, "result": result, "localHash": recomputed,
                "ledgerHash": res.get("ledgerHash"), "txId": res.get("txId")}

    def status(self) -> dict:
        names = {0: "pending", 1: "synced", -1: "conflict", -2: "rejected"}
        out = {v: 0 for v in names.values()}
        for r in self.db.execute("SELECT synced, COUNT(*) c FROM events GROUP BY synced"):
            out[names.get(r["synced"], str(r["synced"]))] = r["c"]
        return out


def main(argv: list[str]) -> int:
    if not argv:
        print(__doc__)
        return 1
    led = Ledger()
    cmd = argv[0]
    if cmd == "sync":
        led.run_sync_forever()
    elif cmd == "status":
        print(json.dumps(led.status(), indent=2))
    elif cmd == "verify" and len(argv) == 2:
        print(json.dumps(led.verify(argv[1]), indent=2))
    elif cmd == "verify-all":
        for r in led.db.execute("SELECT event_id FROM events WHERE synced=1 ORDER BY ts").fetchall():
            v = led.verify(r["event_id"])
            print(f"{v['result']:<14} {v['eventId']}")
    elif cmd == "demo":
        samples = [random.gauss(0, 1) for _ in range(30 * 100)]  # 30 s @ 100 Hz
        eid = led.record_event(DEVICE_ID, "AF", 0.91, samples, fs=100)
        print(eid)
    elif cmd == "tamper" and len(argv) == 2:
        led.db.execute("UPDATE events SET label=CASE label WHEN 'AF' THEN 'NON_AF' ELSE 'AF' END"
                       " WHERE event_id=?", (argv[1],))
        print(f"label flipped locally for {argv[1]}; now run: verify {argv[1]}")
    else:
        print(__doc__)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

// AF edge gateway: local HTTP (127.0.0.1 only) -> Hyperledger Fabric Gateway (gRPC/TLS over Tailscale).
// Python sync worker talks to this; Fabric credentials never leave this process.
//
//   POST /events                {eventId, deviceId, timestamp, label, confidence, recordHash}
//   GET  /events/:id
//   GET  /verify?id=..&hash=..
//   GET  /devices/:id/events
//   GET  /health
import * as grpc from '@grpc/grpc-js';
import { connect, hash, signers, GatewayError, EndorseError } from '@hyperledger/fabric-gateway';
import { createPrivateKey } from 'node:crypto';
import { readFileSync } from 'node:fs';
import http from 'node:http';
import path from 'node:path';

const ID_DIR = process.env.AF_IDENTITY_DIR ?? path.resolve(process.env.HOME ?? '.', 'af-edge/identity');
const MSP_ID = process.env.AF_MSP_ID ?? 'HospitalMSP';
const CHANNEL = process.env.AF_CHANNEL ?? 'afchannel';
const CHAINCODE = process.env.AF_CHAINCODE ?? 'afevents';
const PORT = Number(process.env.AF_GATEWAY_PORT ?? 3001);
// Tried in order; failover if one Hospital peer is down.
const PEERS = (process.env.AF_PEERS ?? 'peer0.hospital.af.local:7051,peer1.hospital.af.local:7051')
  .split(',').map((s) => s.trim()).filter(Boolean);

const credentials = readFileSync(path.join(ID_DIR, 'cert.pem'));
const privateKey = createPrivateKey(readFileSync(path.join(ID_DIR, 'key.pem')));
const tlsRootCert = readFileSync(path.join(ID_DIR, 'tls-ca.pem'));
const signer = signers.newPrivateKeySigner(privateKey);

const RETRYABLE = new Set([grpc.status.UNAVAILABLE, grpc.status.DEADLINE_EXCEEDED]);
let current = null; // { client, gateway, contract, endpoint }
let peerIdx = 0;

function open(endpoint) {
  const client = new grpc.Client(endpoint, grpc.credentials.createSsl(tlsRootCert), {
    'grpc.keepalive_time_ms': 120000,
  });
  const gateway = connect({
    client,
    identity: { mspId: MSP_ID, credentials },
    signer,
    hash: hash.SHA256,
    evaluateOptions: () => ({ deadline: Date.now() + 5000 }),
    endorseOptions: () => ({ deadline: Date.now() + 15000 }),
    submitOptions: () => ({ deadline: Date.now() + 5000 }),
    commitStatusOptions: () => ({ deadline: Date.now() + 60000 }),
  });
  const contract = gateway.getNetwork(CHANNEL).getContract(CHAINCODE);
  return { client, gateway, contract, endpoint };
}

function close() {
  if (!current) return;
  try { current.gateway.close(); } catch { /* ignore */ }
  try { current.client.close(); } catch { /* ignore */ }
  current = null;
}

// Run fn(contract) with peer failover on transport errors.
async function withContract(fn) {
  let lastErr;
  for (let attempt = 0; attempt < PEERS.length; attempt++) {
    if (!current) current = open(PEERS[peerIdx % PEERS.length]);
    try {
      return await fn(current.contract);
    } catch (err) {
      lastErr = err;
      if (err instanceof GatewayError && RETRYABLE.has(err.code)) {
        console.warn(`[gateway] ${current.endpoint} unavailable (${err.code}); failing over`);
        close();
        peerIdx++;
        continue;
      }
      throw err;
    }
  }
  throw lastErr;
}

const utf8 = new TextDecoder();
const parse = (bytes) => (bytes && bytes.length ? JSON.parse(utf8.decode(bytes)) : null);

function errorInfo(err) {
  const details = (err?.details ?? []).map((d) => d.message).filter(Boolean);
  const msg = [err?.message, ...details].join(' | ');
  if (/already exists/i.test(msg)) return { status: 409, error: 'exists', message: msg };
  if (/not found/i.test(msg)) return { status: 404, error: 'not_found', message: msg };
  if (err instanceof GatewayError && RETRYABLE.has(err.code)) return { status: 503, error: 'unreachable', message: msg };
  if (err instanceof EndorseError || /access denied|must be/i.test(msg)) return { status: 400, error: 'rejected', message: msg };
  return { status: 502, error: 'fabric_error', message: msg };
}

async function recordEvent(e) {
  const required = ['eventId', 'deviceId', 'timestamp', 'label', 'confidence', 'recordHash'];
  const missing = required.filter((k) => e[k] === undefined || e[k] === null || e[k] === '');
  if (missing.length) return { status: 400, body: { error: 'bad_request', message: `missing: ${missing.join(',')}` } };

  return withContract(async (contract) => {
    const proposal = contract.newProposal('RecordEvent', {
      arguments: [e.eventId, e.deviceId, e.timestamp, e.label, String(e.confidence), e.recordHash],
    });
    const tx = await proposal.endorse();
    const commit = await tx.submit();
    const status = await commit.getStatus();
    if (!status.successful) {
      return { status: 409, body: { error: 'commit_failed', code: status.code, txId: tx.getTransactionId() } };
    }
    return { status: 201, body: { txId: tx.getTransactionId(), blockNumber: String(status.blockNumber), event: parse(tx.getResult()) } };
  });
}

const evaluate = (name, ...args) =>
  withContract(async (contract) => parse(await contract.evaluateTransaction(name, ...args)));

function send(res, status, body) {
  const data = JSON.stringify(body);
  res.writeHead(status, { 'content-type': 'application/json', 'content-length': Buffer.byteLength(data) });
  res.end(data);
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > 64 * 1024) { reject(new Error('body too large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); } catch (e) { reject(e); } });
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const parts = url.pathname.split('/').filter(Boolean).map(decodeURIComponent);
  try {
    if (req.method === 'GET' && url.pathname === '/health') {
      try {
        await evaluate('EventExists', '__health__');
        return send(res, 200, { ok: true, peer: current?.endpoint });
      } catch (err) {
        return send(res, 503, { ok: false, ...errorInfo(err) });
      }
    }
    if (req.method === 'POST' && url.pathname === '/events') {
      const r = await recordEvent(await readJson(req));
      return send(res, r.status, r.body);
    }
    if (req.method === 'GET' && parts[0] === 'events' && parts.length === 2) {
      return send(res, 200, await evaluate('GetEvent', parts[1]));
    }
    if (req.method === 'GET' && parts[0] === 'events' && parts[2] === 'history') {
      return send(res, 200, await evaluate('GetHistory', parts[1]));
    }
    if (req.method === 'GET' && parts[0] === 'devices' && parts[2] === 'events') {
      return send(res, 200, await evaluate('QueryByDevice', parts[1]));
    }
    if (req.method === 'GET' && url.pathname === '/verify') {
      const id = url.searchParams.get('id');
      const h = url.searchParams.get('hash');
      if (!id || !h) return send(res, 400, { error: 'bad_request', message: 'id and hash required' });
      return send(res, 200, await evaluate('VerifyHash', id, h));
    }
    return send(res, 404, { error: 'no_route' });
  } catch (err) {
    const info = errorInfo(err);
    if (info.status >= 500) console.error('[gateway]', info.message);
    return send(res, info.status, info);
  }
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`[gateway] http://127.0.0.1:${PORT}  msp=${MSP_ID} channel=${CHANNEL} cc=${CHAINCODE} peers=${PEERS.join(',')}`);
});

for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => { server.close(); close(); process.exit(0); });
}
